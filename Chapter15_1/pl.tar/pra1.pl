#!/bin/perl
use warnings;
use v5.16;
use utf8;

system 'date';
system 'echo $HOME';
system "echo \$HOME";
#Fri Nov 18 03:30:13 CST 2022
#/home/oyjh
#/home/oyjh




